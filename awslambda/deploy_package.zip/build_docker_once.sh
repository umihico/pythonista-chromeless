sudo docker build -t serverless_plain_lambda .
