

"""
just exporting funcs for outside test scripts.
"""
from .codedumper import dump_code, load_code
